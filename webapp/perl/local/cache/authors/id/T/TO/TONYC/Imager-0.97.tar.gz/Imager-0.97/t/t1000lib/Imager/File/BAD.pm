package Imager::File::BAD;
use strict;

die "This module fails to load\n";

1;
