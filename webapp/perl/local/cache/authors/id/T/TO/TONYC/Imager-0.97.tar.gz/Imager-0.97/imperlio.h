#ifndef IMAGER_IMPERLIO_H
#define IMAGER_IMPERLIO_H

extern i_io_glue_t *
im_io_new_perlio(pTHX_ PerlIO *handle);

#endif
